-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 14, 2024 at 04:05 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pharmacy`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_credentials`
--

CREATE TABLE `admin_credentials` (
  `USERNAME` varchar(50) NOT NULL,
  `PASSWORD` varchar(50) NOT NULL,
  `PHARMACY_NAME` varchar(50) NOT NULL,
  `ADDRESS` varchar(100) NOT NULL,
  `EMAIL` varchar(50) NOT NULL,
  `CONTACT_NUMBER` varchar(10) NOT NULL,
  `IS_LOGGED_IN` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_bin;

--
-- Dumping data for table `admin_credentials`
--

INSERT INTO `admin_credentials` (`USERNAME`, `PASSWORD`, `PHARMACY_NAME`, `ADDRESS`, `EMAIL`, `CONTACT_NUMBER`, `IS_LOGGED_IN`) VALUES
('admin', 'admin123', 'Quick pharma', 'Ashram Road,Sodepur,Kolkata-700110 ', 'quickpharma@gmail.com', '6284590233', 0);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `ID` int(11) NOT NULL,
  `NAME` varchar(20) NOT NULL,
  `CONTACT_NUMBER` varchar(10) NOT NULL,
  `ADDRESS` varchar(100) NOT NULL,
  `DOCTOR_NAME` varchar(20) NOT NULL,
  `DOCTOR_ADDRESS` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_bin;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`ID`, `NAME`, `CONTACT_NUMBER`, `ADDRESS`, `DOCTOR_NAME`, `DOCTOR_ADDRESS`) VALUES
(4, 'Kiran Suthar', '1234567690', 'Andheri East', 'Anshari', 'Andheri East'),
(6, 'Aditya', '7365687269', 'Virar West', 'D M Gupta', 'Virar West'),
(11, 'Shivam Tiwari', '6862369896', 'Dadar West', 'Dr Kapoor', 'Dadar East'),
(13, 'Varsha Suthar', '7622369694', 'Rani Station', 'Dr Ramesh', 'Rani Station'),
(14, 'Prakash Bhattarai', '9802851472', 'Pokhara-16, Dhikidada', 'Hari Bahadur', 'Matepani-12'),
(15, 'Akash Bhattacharjee', '6289571897', 'Ashram Road, Sodepur, Kolkata', 'Dr PK Guha', 'Chittaranjan Street, Barrackpore, Kolkata-700009');

-- --------------------------------------------------------

--
-- Table structure for table `invoices`
--

CREATE TABLE `invoices` (
  `INVOICE_ID` int(11) NOT NULL,
  `NET_TOTAL` double NOT NULL DEFAULT 0,
  `INVOICE_DATE` date NOT NULL DEFAULT current_timestamp(),
  `CUSTOMER_ID` int(11) NOT NULL,
  `TOTAL_AMOUNT` double NOT NULL,
  `TOTAL_DISCOUNT` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_bin;

--
-- Dumping data for table `invoices`
--

INSERT INTO `invoices` (`INVOICE_ID`, `NET_TOTAL`, `INVOICE_DATE`, `CUSTOMER_ID`, `TOTAL_AMOUNT`, `TOTAL_DISCOUNT`) VALUES
(30, 26, '2024-12-11', 0, 26, 0),
(31, 30, '2024-12-11', 14, 30, 0),
(35, 26, '2024-12-11', 4, 26, 0),
(36, 14.25, '2024-12-11', 14, 15, 0.75),
(37, 119.3675, '2024-12-11', 11, 122.65, 3.2825),
(39, 48.5, '2024-12-11', 15, 50, 1.5),
(40, 216, '2024-12-11', 15, 225, 9),
(42, 47.65, '2024-12-11', 4, 47.65, 0),
(43, 173.5175, '2024-12-11', 15, 182.65, 9.1325),
(45, 180.497, '2024-12-11', 15, 182.65, 2.153),
(46, 47.1735, '2024-12-11', 15, 47.65, 0.47650000000000003),
(47, 392.294, '2024-12-11', 11, 400.3, 8.006),
(48, 307.65, '2024-12-11', 4, 307.65, 0),
(49, 307.65, '2024-12-11', 15, 307.65, 0),
(51, 105, '2024-12-12', 4, 105, 0),
(52, 140, '2024-12-12', 4, 140, 0),
(54, 175, '2024-12-12', 4, 175, 0),
(55, 125, '2024-12-12', 4, 125, 0),
(56, 926.45, '2024-12-12', 4, 955, 28.549999999999997),
(57, 305, '2024-12-12', 4, 305, 0),
(58, 155, '2024-12-12', 4, 155, 0),
(59, 140, '2024-12-12', 4, 140, 0),
(61, 125, '2024-12-14', 4, 125, 0),
(62, 110, '2024-12-14', 4, 110, 0),
(63, 30, '2024-12-14', 4, 30, 0),
(64, 30, '2024-12-14', 4, 30, 0),
(65, 75, '2024-12-14', 6, 75, 0),
(66, 90, '2024-12-14', 14, 90, 0),
(67, 30, '2024-12-14', 14, 30, 0),
(70, 90, '2024-12-14', 4, 90, 0),
(71, 155, '2024-12-14', 4, 155, 0),
(72, 192.95, '2024-12-14', 4, 200, 7.05);

-- --------------------------------------------------------

--
-- Table structure for table `medicines`
--

CREATE TABLE `medicines` (
  `ID` int(11) NOT NULL,
  `NAME` varchar(100) NOT NULL,
  `PACKING` varchar(20) NOT NULL,
  `GENERIC_NAME` varchar(100) NOT NULL,
  `SUPPLIER_NAME` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_bin;

--
-- Dumping data for table `medicines`
--

INSERT INTO `medicines` (`ID`, `NAME`, `PACKING`, `GENERIC_NAME`, `SUPPLIER_NAME`) VALUES
(1, 'Nicip Plus', '10tab', 'Paracetamole', 'BDPL PHARMA'),
(2, 'Crosin', '10TAB', 'Crosin', 'Kiran Pharma'),
(4, 'Dolo 650', '15tab', 'paracetamole', 'BDPL PHARMA'),
(5, 'Gelusil', '10tab', 'mint fla', 'Desai Pharma'),
(6, 'Crosin', '1', 'Non', 'Desai Pharma'),
(7, 'Paracitemol', '2', 'Paracitemol', 'Desai Pharma'),
(9, 'DOLO15', '20 TAB', 'DOLO', 'Desai Pharma'),
(10, 'DOLO15', '1', 'DOLO', 'Desai Pharma'),
(11, 'DOLO15', '10TAB', 'DOLO', 'BDPL PHARMA'),
(14, 'Dolo 650', '10TAB', 'DOLO', 'Desai Pharma'),
(15, 'Crosin', '10TAB', 'Crosin', 'Desai Pharma'),
(16, 'Allegra', '10TAB', 'Allegra', 'Desai Pharma'),
(17, 'Ascoril', '10BOTTLE', 'Ascoril', 'Dwaipayan Pharma');

-- --------------------------------------------------------

--
-- Table structure for table `medicines_stock`
--

CREATE TABLE `medicines_stock` (
  `ID` int(11) NOT NULL,
  `NAME` varchar(100) NOT NULL,
  `BATCH_ID` varchar(20) NOT NULL,
  `EXPIRY_DATE` varchar(10) NOT NULL,
  `QUANTITY` int(11) NOT NULL,
  `MRP` double NOT NULL,
  `RATE` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_bin;

--
-- Dumping data for table `medicines_stock`
--

INSERT INTO `medicines_stock` (`ID`, `NAME`, `BATCH_ID`, `EXPIRY_DATE`, `QUANTITY`, `MRP`, `RATE`) VALUES
(1, 'Crosin', 'CROS12', '12/34', 282, 30, 15),
(2, 'Gelusil', 'G327', '12/42', 132, 15, 12),
(3, 'Dolo 650', 'DOLO327', '01/25', 109, 30, 24),
(4, 'Nicip Plus', 'NI325', '05/25', 96, 30, 28),
(5, 'Allegra', 'ALG102', '05/25', 96, 50, 20),
(6, 'Ascoril', 'ASC128', '05/25', 109, 150, 90);

-- --------------------------------------------------------

--
-- Table structure for table `purchases`
--

CREATE TABLE `purchases` (
  `SUPPLIER_NAME` varchar(100) NOT NULL,
  `INVOICE_NUMBER` int(11) NOT NULL,
  `VOUCHER_NUMBER` int(11) NOT NULL,
  `PURCHASE_DATE` varchar(10) NOT NULL,
  `TOTAL_AMOUNT` double NOT NULL,
  `PAYMENT_STATUS` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_bin;

--
-- Dumping data for table `purchases`
--

INSERT INTO `purchases` (`SUPPLIER_NAME`, `INVOICE_NUMBER`, `VOUCHER_NUMBER`, `PURCHASE_DATE`, `TOTAL_AMOUNT`, `PAYMENT_STATUS`) VALUES
('Desai Pharma', 122201, 1, '2024-09-12', 60, 'PAID'),
('Gahgkakbvkv', 123355, 2, '2024-09-14', 50, 'PAID'),
('Desai Pharma', 1, 3, '2024-10-26', 250, 'PAID'),
('Desai Pharma', 5, 4, '2024-10-26', 250, 'PAID'),
('BDPL PHARMA', 10, 5, '2024-10-26', 50, 'PAID'),
('Desai Pharma', 1255, 6, '2024-11-07', 5, 'PAID'),
('BDPL PHARMA', 7, 7, '2024-12-11', 1500, 'PAID'),
('Desai Pharma', 8, 8, '2024-12-11', 150, 'PAID'),
('Desai Pharma', 9, 9, '2024-12-11', 1500, 'PAID'),
('Desai Pharma', 11, 10, '2024-12-11', 200, 'PAID'),
('Dwaipayan Pharma', 12, 11, '2024-12-11', 900, 'PAID');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `SALE_ID` int(11) NOT NULL,
  `CUSTOMER_ID` int(11) NOT NULL,
  `INVOICE_NUMBER` int(11) NOT NULL,
  `BATCH_ID` varchar(20) NOT NULL,
  `MEDICINE_NAME` varchar(50) NOT NULL,
  `QUANTITY` int(11) NOT NULL,
  `EXPIRY_DATE` varchar(10) NOT NULL,
  `DISCOUNT` int(100) NOT NULL,
  `MRP` double NOT NULL,
  `TOTAL` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_bin;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`SALE_ID`, `CUSTOMER_ID`, `INVOICE_NUMBER`, `BATCH_ID`, `MEDICINE_NAME`, `QUANTITY`, `EXPIRY_DATE`, `DISCOUNT`, `MRP`, `TOTAL`) VALUES
(6, 14, 31, 'DOLO327', 'Dolo 650', 1, '01/25', 0, 30, 30),
(10, 4, 35, 'CROS12', 'Crosin', 1, '12/34', 0, 26, 26),
(11, 14, 36, 'G327', 'Gelusil', 1, '12/42', 5, 15, 14.25),
(14, 11, 37, 'G327', 'Gelusil', 1, '12/42', 1, 15, 14.85),
(16, 15, 39, 'ALG102', 'Allegra', 1, '05/25', 3, 50, 48.5),
(18, 15, 40, 'ASC128', 'Ascoril', 1, '05/25', 5, 150, 142.5),
(21, 4, 42, 'NI325', 'Nicip Plus', 1, '05/25', 0, 32.65, 32.65),
(22, 4, 42, 'G327', 'Gelusil', 1, '12/42', 0, 15, 15),
(24, 15, 43, 'NI325', 'Nicip Plus', 1, '05/25', 5, 32.65, 31.0175),
(27, 15, 45, 'ASC128', 'Ascoril', 1, '05/25', 1, 150, 148.5),
(28, 15, 45, 'NI325', 'Nicip Plus', 1, '05/25', 2, 32.65, 31.997),
(29, 15, 46, 'G327', 'Gelusil', 1, '12/42', 1, 15, 14.85),
(30, 15, 46, 'NI325', 'Nicip Plus', 1, '05/25', 1, 32.65, 32.323499999999996),
(34, 11, 47, 'ASC128', 'Ascoril', 1, '05/25', 2, 150, 147),
(35, 11, 47, 'DOLO327', 'Dolo 650', 2, '01/25', 2, 30, 58.8),
(36, 11, 47, 'G327', 'Gelusil', 1, '12/42', 2, 15, 14.7),
(40, 4, 48, 'ALG102', 'Allegra', 1, '05/25', 0, 50, 50),
(41, 4, 48, 'ASC128', 'Ascoril', 1, '05/25', 0, 150, 150),
(42, 4, 48, 'DOLO327', 'Dolo 650', 1, '01/25', 0, 30, 30),
(47, 15, 49, 'DOLO327', 'Dolo 650', 1, '01/25', 0, 30, 30),
(48, 15, 49, 'ASC128', 'Ascoril', 1, '05/25', 0, 150, 150),
(55, 4, 51, 'G327', 'Gelusil', 1, '12/42', 0, 15, 15),
(56, 4, 51, 'NI325', 'Nicip Plus', 1, '05/25', 0, 30, 30),
(59, 4, 52, 'DOLO327', 'Dolo 650', 1, '01/25', 0, 30, 30),
(60, 4, 52, 'ALG102', 'Allegra', 1, '05/25', 0, 50, 50),
(69, 4, 54, 'CROS12', 'Crosin', 1, '12/34', 0, 30, 30),
(70, 4, 54, 'ALG102', 'Allegra', 1, '05/25', 0, 50, 50),
(71, 4, 54, 'ALG102', 'Allegra', 1, '05/25', 0, 50, 50),
(72, 4, 55, 'DOLO327', 'Dolo 650', 1, '01/25', 0, 30, 30),
(73, 4, 55, 'ALG102', 'Allegra', 1, '05/25', 0, 50, 50),
(74, 4, 55, 'CROS12', 'Crosin', 1, '12/34', 0, 30, 30),
(75, 4, 55, 'G327', 'Gelusil', 1, '12/42', 0, 15, 15),
(92, 4, 58, 'ALG102', 'Allegra', 1, '05/25', 0, 50, 50),
(96, 4, 59, 'ALG102', 'Allegra', 1, '05/25', 0, 50, 50),
(109, 4, 64, 'CROS12', 'Crosin', 1, '12/34', 0, 30, 30),
(111, 6, 65, 'G327', 'Gelusil', 1, '12/42', 0, 15, 15),
(112, 6, 65, 'DOLO327', 'Dolo 650', 1, '01/25', 0, 30, 30),
(114, 14, 66, 'NI325', 'Nicip Plus', 1, '05/25', 0, 30, 30),
(115, 14, 66, 'DOLO327', 'Dolo 650', 1, '01/25', 0, 30, 30),
(116, 14, 67, 'CROS12', 'Crosin', 1, '12/34', 0, 30, 30),
(124, 4, 70, 'NI325', 'Nicip Plus', 1, '05/25', 0, 30, 30),
(125, 4, 71, 'G327', 'Gelusil', 1, '12/42', 0, 15, 15),
(126, 4, 71, 'DOLO327', 'Dolo 650', 1, '01/25', 0, 30, 30),
(127, 4, 71, 'CROS12', 'Crosin', 1, '12/34', 0, 30, 30),
(128, 4, 71, 'NI325', 'Nicip Plus', 1, '05/25', 0, 30, 30),
(129, 4, 71, 'ALG102', 'Allegra', 1, '05/25', 0, 50, 50),
(130, 4, 72, 'CROS12', 'Crosin', 1, '12/34', 2, 30, 29.55),
(131, 4, 72, 'NI325', 'Nicip Plus', 1, '05/25', 5, 30, 28.5),
(132, 4, 72, 'NI325', 'Nicip Plus', 1, '05/25', 2, 30, 29.4),
(133, 4, 72, 'NI325', 'Nicip Plus', 1, '05/25', 3, 30, 29.1),
(134, 4, 72, 'ALG102', 'Allegra', 1, '05/25', 6, 50, 47),
(135, 4, 72, 'NI325', 'Nicip Plus', 1, '05/25', 2, 30, 29.4);

-- --------------------------------------------------------

--
-- Table structure for table `suppliers`
--

CREATE TABLE `suppliers` (
  `ID` int(11) NOT NULL,
  `NAME` varchar(100) NOT NULL,
  `EMAIL` varchar(100) NOT NULL,
  `CONTACT_NUMBER` varchar(10) NOT NULL,
  `ADDRESS` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_bin;

--
-- Dumping data for table `suppliers`
--

INSERT INTO `suppliers` (`ID`, `NAME`, `EMAIL`, `CONTACT_NUMBER`, `ADDRESS`) VALUES
(1, 'Desai Pharma', 'desai@gmail.com', '9948724242', 'Mahim East'),
(2, 'BDPL PHARMA', 'bdpl@gmail.com', '8645632963', 'Santacruz West'),
(9, 'Kiran Pharma', 'kiranpharma@gmail.com', '7638683637', 'Andheri East'),
(10, 'Rudro Day', 'rudroday03@gmail.com', '9156845695', 'Kolkata North'),
(11, 'Dibendu Pharama', 'dibendu04@gmail.com', '9156885665', 'Agarpara Central'),
(30, 'Dwaipayan Pharma', 'dwaipaya05@gmail.com', '7044435217', 'Saktipure, Agarpara, Kolkata-700109');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_credentials`
--
ALTER TABLE `admin_credentials`
  ADD PRIMARY KEY (`USERNAME`) USING BTREE;

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `invoices`
--
ALTER TABLE `invoices`
  ADD PRIMARY KEY (`INVOICE_ID`);

--
-- Indexes for table `medicines`
--
ALTER TABLE `medicines`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `medicines_stock`
--
ALTER TABLE `medicines_stock`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `BATCH_ID` (`BATCH_ID`);

--
-- Indexes for table `purchases`
--
ALTER TABLE `purchases`
  ADD PRIMARY KEY (`VOUCHER_NUMBER`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`SALE_ID`),
  ADD KEY `INVOICE_ID` (`INVOICE_NUMBER`),
  ADD KEY `sales_ibfk_2` (`BATCH_ID`);

--
-- Indexes for table `suppliers`
--
ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `invoices`
--
ALTER TABLE `invoices`
  MODIFY `INVOICE_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=73;

--
-- AUTO_INCREMENT for table `medicines`
--
ALTER TABLE `medicines`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `medicines_stock`
--
ALTER TABLE `medicines_stock`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `purchases`
--
ALTER TABLE `purchases`
  MODIFY `VOUCHER_NUMBER` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `SALE_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=136;

--
-- AUTO_INCREMENT for table `suppliers`
--
ALTER TABLE `suppliers`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `sales`
--
ALTER TABLE `sales`
  ADD CONSTRAINT `sales_ibfk_1` FOREIGN KEY (`INVOICE_NUMBER`) REFERENCES `invoices` (`INVOICE_ID`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `sales_ibfk_2` FOREIGN KEY (`BATCH_ID`) REFERENCES `medicines_stock` (`BATCH_ID`) ON DELETE CASCADE ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
