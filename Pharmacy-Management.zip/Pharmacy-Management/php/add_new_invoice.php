<?php
  if(isset($_GET['action']) && $_GET['action'] == "add_row")
    createMedicineInfoRow();

  if(isset($_GET['action']) && $_GET['action'] == "is_customer")
    isCustomer(strtoupper($_GET['name']), $_GET['contact_number']);

  if(isset($_GET['action']) && $_GET['action'] == "is_invoice")
    isInvoiceExist($_GET['invoice_number']);

  if(isset($_GET['action']) && $_GET['action'] == "is_medicine")
    isMedicine(strtoupper($_GET['name']));

  if(isset($_GET['action']) && $_GET['action'] == "current_invoice_number")
    getInvoiceNumber();

  if(isset($_GET['action']) && $_GET['action'] == "medicine_list")
    showMedicineList(strtoupper($_GET['text']));

  if(isset($_GET['action']) && $_GET['action'] == "fill")
    fill(strtoupper($_GET['name']), $_GET['column']);

  if(isset($_GET['action']) && $_GET['action'] == "check_quantity")
    checkAvailableQuantity(strtoupper($_GET['medicine_name']));

  if(isset($_GET['action']) && $_GET['action'] == "update_stock")
    updateStock(strtoupper($_GET['name']), $_GET['batch_id'], intval($_GET['quantity']));

  if(isset($_GET['action']) && $_GET['action'] == "add_sale")
    addSale($_GET['customer_id'], $_GET['invoice_number'], $_GET['medicine_name'], $_GET['batch_id'], $_GET['expiry_date'], intval($_GET['quantity']), $_GET['mrp'], $_GET['discount'], $_GET['total']);

  if(isset($_GET['action']) && $_GET['action'] == "add_new_invoice")
    addNewInvoice($_GET['customer_id'], $_GET['invoice_date'], $_GET['total_amount'], $_GET['total_discount'], $_GET['net_total']);

  function isCustomer($name, $contact_number) {
    require "db_connection.php";
    if($con) {
      $query = "SELECT * FROM customers WHERE UPPER(NAME) = '$name' AND CONTACT_NUMBER = '$contact_number'";
      $result = mysqli_query($con, $query);
      $row = mysqli_fetch_array($result);
      echo ($row) ? "true" : "false";
    }
  }

  function isInvoiceExist($invoice_number) {
    require "db_connection.php";
    if($con) {
      $query = "SELECT * FROM sales WHERE INVOICE_NUMBER = $invoice_number";
      $result = mysqli_query($con, $query);
      $row = mysqli_fetch_array($result);
      echo ($row) ? "true" : "false";
    }
  }

  function isMedicine($name) {
    require "db_connection.php";
    if($con) {
      $query = "SELECT * FROM medicines_stock WHERE UPPER(NAME) = '$name'";
      $result = mysqli_query($con, $query);
      $row = mysqli_fetch_array($result);
      echo ($row) ? "true" : "false";
    }
  }

  function createMedicineInfoRow() {
    $row_id = $_GET['row_id'];
    $row_number = $_GET['row_number'];
    ?>
    <div class="row col col-md-12">
      <div class="col-md-2">
        <input id="medicine_name_<?php echo $row_number; ?>" name="medicine_name" class="form-control" list="medicine_list_<?php echo $row_number; ?>" placeholder="Select Medicine" onkeydown="medicineOptions(this.value, 'medicine_list_<?php echo $row_number; ?>');" onfocus="medicineOptions(this.value, 'medicine_list_<?php echo $row_number; ?>');" onchange="fillFields(this.value, '<?php echo $row_number; ?>');">
        <code class="text-danger small font-weight-bold float-right" id="medicine_name_error_<?php echo $row_number; ?>" style="display: none;"></code>
        <datalist id="medicine_list_<?php echo $row_number; ?>" style="display: none; max-height: 200px; overflow: auto;">
          <?php showMedicineList("") ?>
        </datalist>
      </div>
      <div class="col col-md-2"><input type="text" class="form-control" id="batch_id_<?php echo $row_number; ?>" disabled></div>
      <div class="col col-md-1"><input type="number" class="form-control" id="available_quantity_<?php echo $row_number; ?>" disabled></div>
      <div class="col col-md-1"><input type="text" class="form-control" id="expiry_date_<?php echo $row_number; ?>" disabled></div>
      <div class="col col-md-1">
        <input type="number" class="form-control" id="quantity_<?php echo $row_number; ?>" value="0" onkeyup="getTotal('<?php echo $row_number; ?>');" onblur="checkAvailableQuantity(this.value, '<?php echo $row_number; ?>');">
        <code class="text-danger small font-weight-bold float-right" id="quantity_error_<?php echo $row_number; ?>" style="display: none;"></code>
      </div>
      <div class="col col-md-1"><input type="number" class="form-control" id="mrp_<?php echo $row_number; ?>" onchange="getTotal('<?php echo $row_number; ?>');" disabled></div>
      <div class="col col-md-1">
        <input type="number" class="form-control" id="discount_<?php echo $row_number; ?>" value="0" onkeyup="getTotal('<?php echo $row_number; ?>');">
        <code class="text-danger small font-weight-bold float-right" id="discount_error_<?php echo $row_number; ?>" style="display: none;"></code>
      </div>
      <div class="col col-md-1"><input type="number" class="form-control" id="total_<?php echo $row_number; ?>" disabled></div>
      <div class="col col-md-2">
        <button class="btn btn-primary" onclick="addRow();">
          <i class="fa fa-plus"></i>
        </button>
        <button class="btn btn-danger"  onclick="removeRow('<?php echo $row_id ?>');">
          <i class="fa fa-trash"></i>
        </button>
      </div>
    </div>
    <div class="col col-md-12">
      <hr class="col-md-12" style="padding: 0px;">
    </div>
    <?php
  }

  function getInvoiceNumber() {
    require 'db_connection.php';
    if($con) {
      $query = "SELECT AUTO_INCREMENT FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'pharmacy' AND TABLE_NAME = 'invoices';";
      $result = mysqli_query($con, $query);
      $row = mysqli_fetch_array($result);
      echo $row['AUTO_INCREMENT'];
    }
  }

  function showMedicineList($text) {
    require 'db_connection.php';
    if($con) {
      if($text == "")
        $query = "SELECT * FROM medicines_stock";
      else
        $query = "SELECT * FROM medicines_stock WHERE UPPER(NAME) LIKE '%$text%'";
      $result = mysqli_query($con, $query);
      while($row = mysqli_fetch_array($result))
        echo '<option value="'.$row['NAME'].'">'.$row['NAME'].'</option>';
    }
  }

  function fill($name, $column) {
    require 'db_connection.php';
    if($con) {
      $query = "SELECT * FROM medicines_stock WHERE UPPER(NAME) = '$name'";
      $result = mysqli_query($con, $query);
      if(mysqli_num_rows($result) != 0) {
        $row = mysqli_fetch_array($result);
        echo $row[$column];
      }
    }
  }

  function checkAvailableQuantity($name) {
    require "db_connection.php";
    if($con) {
      $query = "SELECT QUANTITY FROM medicines_stock WHERE UPPER(NAME) = '$name'";
      $result = mysqli_query($con, $query);
      $row = mysqli_fetch_array($result);
      echo ($row) ? $row['QUANTITY'] : "false";
    }
  }

  function updateStock($name, $batch_id, $quantity) {
    require "db_connection.php";
    if($con) {
      $query = "UPDATE medicines_stock SET QUANTITY = QUANTITY - $quantity WHERE UPPER(NAME) = '$name' AND BATCH_ID = '$batch_id'";
      $result = mysqli_query($con, $query);
      echo ($result) ? "stock updated" : "failed to update stock";
    }
  }

  function getCustomerId($name, $contact_number) {
    require "db_connection.php";
    if($con) {
      $query = "SELECT ID FROM customers WHERE UPPER(NAME) = '$name' AND CONTACT_NUMBER = '$contact_number'";
      $result = mysqli_query($con, $query);
      $row = mysqli_fetch_array($result);
      return ($row) ? $row['ID'] : 0;
    }
  }

  function addSale($customer_id, $invoice_number, $medicine_name, $batch_id, $expiry_date, $quantity, $mrp, $discount, $total) {
    require "db_connection.php";
    if ($con) {
        $query = "INSERT INTO sales (CUSTOMER_ID, INVOICE_NUMBER, MEDICINE_NAME, BATCH_ID, EXPIRY_DATE, QUANTITY, MRP, DISCOUNT, TOTAL) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $con->prepare($query);
        $stmt->bind_param("iisssiddd", $customer_id, $invoice_number, $medicine_name, $batch_id, $expiry_date, $quantity, $mrp, $discount, $total);
        if ($stmt->execute()) {
            echo "Inserted sale.";
        } else {
            echo "Failed to add sale: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "Database connection failed.";
    }
}

function addNewInvoice($customer_id, $invoice_date, $total_amount, $total_discount, $net_total) {
    require "db_connection.php";
    if ($con) {
        $query = "INSERT INTO invoices (CUSTOMER_ID, INVOICE_DATE, TOTAL_AMOUNT, TOTAL_DISCOUNT, NET_TOTAL) VALUES (?, ?, ?, ?, ?)";
        $stmt = $con->prepare($query);
        $stmt->bind_param("issdd", $customer_id, $invoice_date, $total_amount, $total_discount, $net_total);
        if ($stmt->execute()) {
            echo "Invoice saved.";
        } else {
            echo "Failed to add invoice: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "Database connection failed.";
    }
}




//   function addNewInvoice() {
//     // Step 1: Validate and sanitize inputs
//      if (isset($_GET['customers_name'], $_GET['customers_contact_number'], $_GET['invoice_date'],
//     $_GET['total_amount'], $_GET['total_discount'], $_GET['net_total'],
//     $_GET['invoice_number'], $_GET['batch_id'], $_GET['medicine_name'], $_GET['expiry_date'],
//     $_GET['quantity'], $_GET['mrp'], $_GET['discount'], $_GET['total'])) {
// echo "All required parameters are present.";
// } else {
// echo "Missing parameters: ";
// foreach (['customers_name', 'customers_contact_number', 'invoice_date', 'total_amount', 'total_discount',
//         'net_total', 'invoice_id', 'medicine_name', 'expiry_date', 'quantity', 'mrp', 'discount', 'total'] as $param) {
//   if (!isset($_GET[$param])) {
//       echo $param . " ";
//   }
// }
// }
// {
//         $customers_name = strtoupper(trim($_GET['customers_name']));
//         $customers_contact_number = trim($_GET['customers_contact_number']);
//         $invoice_date = trim($_GET['invoice_date']);
//         $total_amount = (float) $_GET['total_amount'];
//         $total_discount = (float) $_GET['total_discount'];
//         $net_total = (float) $_GET['net_total'];
//         $batch_id = trim($_GET['batch_id']);
//         $invoice_number = (int) $_GET['invoice_number'];
//         $medicine_name = trim($_GET['medicine_name']);
//         $expiry_date = trim($_GET['expiry_date']);
//         $quantity = (int) $_GET['quantity'];
//         $mrp = (float) $_GET['mrp'];
//         $discount = (float) $_GET['discount'];
//         $total = (float) $_GET['total'];

//         // Step 2: Establish Database Connection
//         require "db_connection.php";
//         if ($con) {
//             // Step 3: Get Customer ID
//             $customer_id = getCustomerId($customers_name, $customers_contact_number);

//             // Step 4: Insert Invoice
//             $query_invoice = "INSERT INTO invoices (CUSTOMER_ID, INVOICE_DATE, TOTAL_AMOUNT, TOTAL_DISCOUNT, NET_TOTAL)
//                               VALUES (?, ?, ?, ?, ?)";
//             $stmt_invoice = $con->prepare($query_invoice);
//             $stmt_invoice->bind_param("issdd", $customer_id, $invoice_date, $total_amount, $total_discount, $net_total);
//             if ($stmt_invoice->execute()) {
//                 echo "Invoice saved...";
//             } else {
//                 echo "Failed to add invoice: " . $stmt_invoice->error;
//             }
//             $stmt_invoice->close();

//             sleep(2);

//             // Step 5: Insert Sales
//             $query_sales = "INSERT INTO sales (CUSTOMER_ID,CUSTOMERS_NAME,CUSTOMERS_CONTACT_NUMBER, BATCH_ID, INVOICE_NUMBER, MEDICINE_NAME, EXPIRY_DATE, QUANTITY, MRP, DISCOUNT, TOTAL)
//                             VALUES ( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
//             $stmt_sales = $con->prepare($query_sales);
//             $stmt_sales->bind_param("iissiddi", $customer_id, $customers_name, $customers_contact_number, $batch_id, $invoice_number, $medicine_name, $expiry_date, $quantity, $mrp, $discount, $total);
//             if ($stmt_sales->execute()) {
//                 echo "Inserted sale...";
//             } else {
//                 echo "Failed to add sale: " . $stmt_sales->error;
//             }
//             $stmt_sales->close();
//         } else {
//             echo "Database connection failed.";
//         }
//     }
// }


// function addNewInvoice() {
//     // Log all incoming GET data for debugging
//     echo "<pre>";
//     print_r($_GET); // Log incoming data
//     echo "</pre>";

//     // Check if all required parameters are present
//     if (isset($_GET['customers_name'], $_GET['customers_contact_number'], $_GET['invoice_date'],
//         $_GET['total_amount'], $_GET['total_discount'], $_GET['net_total'],
//         $_GET['invoice_number'], $_GET['batch_id'], $_GET['medicine_name'], $_GET['expiry_date'],
//         $_GET['quantity'], $_GET['mrp'], $_GET['discount'], $_GET['total'])) {

//         // Sanitize and assign input values
//         $customers_name = strtoupper(trim($_GET['customers_name']));
//         $customers_contact_number = trim($_GET['customers_contact_number']);
//         $invoice_date = trim($_GET['invoice_date']);
//         $total_amount = (float)$_GET['total_amount'];
//         $total_discount = (float)$_GET['total_discount'];
//         $net_total = (float)$_GET['net_total'];
//         $batch_id = trim($_GET['batch_id']);
//         $invoice_number = (int)$_GET['invoice_number'];
//         $medicine_name = trim($_GET['medicine_name']);
//         $expiry_date = trim($_GET['expiry_date']);
//         $quantity = (int)$_GET['quantity'];
//         $mrp = (float)$_GET['mrp'];
//         $discount = (float)$_GET['discount'];
//         $total = (float)$_GET['total'];

//         // Database Connection
//         require "db_connection.php";
//         if ($con) {
//             // Get Customer ID
//             $customer_id = getCustomerId($customers_name, $customers_contact_number);

//             // Insert Invoice
//             $query_invoice = "INSERT INTO invoices (CUSTOMER_ID, INVOICE_DATE, TOTAL_AMOUNT, TOTAL_DISCOUNT, NET_TOTAL)
//                               VALUES (?, ?, ?, ?, ?)";
//             $stmt_invoice = $con->prepare($query_invoice);
//             $stmt_invoice->bind_param("issdd", $customer_id, $invoice_date, $total_amount, $total_discount, $net_total);
//             if ($stmt_invoice->execute()) {
//                 echo "Invoice saved...";
//             } else {
//                 echo "Failed to add invoice: " . $stmt_invoice->error;
//             }
//             $stmt_invoice->close();

//             sleep(2); // Simulate delay for demonstration purposes

//             // Insert Sale
//             $query_sales = "INSERT INTO sales (CUSTOMER_ID, CUSTOMERS_NAME, CUSTOMERS_CONTACT_NUMBER, BATCH_ID, INVOICE_NUMBER, MEDICINE_NAME, EXPIRY_DATE, QUANTITY, MRP, DISCOUNT, TOTAL)
//                             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
//             $stmt_sales = $con->prepare($query_sales);
//             $stmt_sales->bind_param("issisissidd", $customer_id, $customers_name, $customers_contact_number, $batch_id, $invoice_number, $medicine_name, $expiry_date, $quantity, $mrp, $discount, $total);
//             if ($stmt_sales->execute()) {
//                 echo "Inserted sale...";
//             } else {
//                 echo "Failed to add sale: " . $stmt_sales->error;
//             }
//             $stmt_sales->close();
//         } else {
//             echo "Database connection failed.";
//         }
//     } else {
//         // Log missing parameters
//         echo "Missing parameters: ";
//         foreach (['customers_name', 'customers_contact_number', 'invoice_date', 'total_amount', 'total_discount',
//             'net_total', 'invoice_number', 'medicine_name', 'expiry_date', 'quantity', 'mrp', 'discount', 'total'] as $param) {
//             if (!isset($_GET[$param])) {
//                 echo $param . " ";
//             }
//         }
//     }
// }


 ?>



